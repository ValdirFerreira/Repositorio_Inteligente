﻿using Data.Entidades;
using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Interfaces
{
    public interface IRepositorio
    {
        IList<Usuario> ListarUsuario();
        IList<Produto> ListarProduto();


        void AdicionarListaProduto(List<Produto> produto);

        void AdicionarListaUsuario(List<Usuario> usuario);

    }
}
