﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Entidades
{
    public class Produto : EntidadeBase
    {
    }
}
