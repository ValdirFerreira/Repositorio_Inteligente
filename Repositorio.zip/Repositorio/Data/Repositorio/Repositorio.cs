﻿using Data.Contexto;
using Data.Entidades;
using Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Data.Repositorio
{
    public class Repositorio : IRepositorio
    {

        private readonly DbContextOptionsBuilder<ContextoBase> _optionsBuilder;


        public Repositorio()
        {
            _optionsBuilder = new DbContextOptionsBuilder<ContextoBase>();
        }



        public void AdicionarListaProduto(List<Produto> produto)
        {
            using (var banco = new ContextoBase(_optionsBuilder.Options))
            {
                banco.Produto.AddRange(produto);
                banco.SaveChanges();
            }
        }

        public void AdicionarListaUsuario(List<Usuario> usuario)
        {
            using (var banco = new ContextoBase(_optionsBuilder.Options))
            {
                banco.Usuario.AddRange(usuario);
                banco.SaveChanges();
            }
        }

        public IList<Produto> ListarProduto()
        {
            using (var banco = new ContextoBase(_optionsBuilder.Options))
            {

                return banco.Produto.ToList();
            }
        }

        public IList<Usuario> ListarUsuario()
        {
            using (var banco = new ContextoBase(_optionsBuilder.Options))
            {

                return banco.Usuario.ToList();
            }
        }
    }
}
