﻿
using Data.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Contexto
{
    public class ContextoBase : DbContext
    {

        public ContextoBase(DbContextOptions<ContextoBase> options) : base(options)
        {
           // Database.EnsureCreated();
        }

        public ContextoBase()
        {
           // Database.EnsureCreated();
        }


        public DbSet<Usuario> Usuario { get; set; }
        public DbSet<Produto> Produto { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Se não estiver configurado no projeto IU pega deginição de chame do json configurado
            if (!optionsBuilder.IsConfigured)
                optionsBuilder.UseSqlServer(GetStringConectionConfig());

            base.OnConfiguring(optionsBuilder);
        }

        private string GetStringConectionConfig()
        {
            string strCon = "Data Source=DESKTOP-FLR1ARP;Initial Catalog=repositorio_aula;Integrated Security=False;User ID=sa;Password=1234;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False";

            return strCon;
        }


    }
}
