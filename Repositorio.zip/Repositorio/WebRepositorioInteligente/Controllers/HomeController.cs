﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Data.Entidades;
using Data.Interfaces;
using Microsoft.AspNetCore.Mvc;
using WebRepositorioInteligente.Models;

namespace WebRepositorioInteligente.Controllers
{
    public class HomeController : Controller
    {

        private readonly IRepositorio _repositorio;


        public HomeController(IRepositorio repositorio)
        {
            _repositorio = repositorio;
        }


        public IActionResult Index()
        {

            //var ListaUsuarios = new List<Usuario>();
            //var ListaProduto = new List<Produto>();

            //for (int i = 1; i < 30; i++)
            //{
            //    ListaUsuarios.Add(new Usuario { Nome = "Usuario - " + i.ToString() });

            //    ListaProduto.Add(new Produto { Nome = "Produto - " + i.ToString() });
            //}

            //_repositorio.AdicionarListaProduto(ListaProduto);

            //_repositorio.AdicionarListaUsuario(ListaUsuarios);


            var listarProdutos = _repositorio.ListarProduto();


            var listarUsuarios = _repositorio.ListarUsuario();


            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
